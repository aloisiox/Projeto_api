package com.livros.projeto.dtos;

import com.livros.projeto.models.Categoria;

public class CategoriaMapper {

    public static CategoriaDTO paraDTO(Categoria categoria) {
        return new CategoriaDTO(
                categoria.getId(),
                categoria.getNome(),
                categoria.getDescricao()
        );
    }

    public static Categoria paraEntidade(CategoriaDTO dto) {
        Categoria categoria = new Categoria();
        categoria.setNome(dto.getNome());
        categoria.setDescricao(dto.getDescricao());
        return categoria;
    }
}
