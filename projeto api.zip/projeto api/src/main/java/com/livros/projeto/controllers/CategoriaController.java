package com.livros.projeto.controllers;

import com.livros.projeto.dtos.CategoriaDTO;
import com.livros.projeto.dtos.CategoriaMapper;
import com.livros.projeto.models.Categoria;
import com.livros.projeto.repositories.CategoriaRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/categorias")
public class CategoriaController {

    private final CategoriaRepository repository;

    public CategoriaController(CategoriaRepository repository) {
        this.repository = repository;
    }

    @GetMapping
    public ResponseEntity<List<CategoriaDTO>> listarTodas() {
        List<CategoriaDTO> categorias = repository.findAll().stream()
                .map(CategoriaMapper::paraDTO)
                .toList();

        return ResponseEntity.ok(categorias);
    }

    @GetMapping("/{id}")
    public ResponseEntity<CategoriaDTO> buscarPorId(@PathVariable Long id) {
        return repository.findById(id)
                .map(CategoriaMapper::paraDTO)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<CategoriaDTO> criar(@RequestBody CategoriaDTO dto) {
        Categoria categoria = CategoriaMapper.paraEntidade(dto);
        Categoria categoriaSalva = repository.save(categoria);

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(CategoriaMapper.paraDTO(categoriaSalva));
    }

    @PutMapping("/{id}")
    public ResponseEntity<CategoriaDTO> atualizar(
            @PathVariable Long id,
            @RequestBody CategoriaDTO dto
    ) {
        if (!repository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }

        Categoria categoria = CategoriaMapper.paraEntidade(dto);
        categoria.setId(id);
        Categoria categoriaSalva = repository.save(categoria);

        return ResponseEntity.ok(CategoriaMapper.paraDTO(categoriaSalva));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        if (!repository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }

        repository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
