package com.livros.projeto.controllers;

import com.livros.projeto.dtos.AutorDTO;
import com.livros.projeto.dtos.AutorMapper;
import com.livros.projeto.models.Autor;
import com.livros.projeto.repositories.AutorRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/autores")
public class AutorController {
    private final AutorRepository repository;

    public AutorController(AutorRepository repository) { this.repository = repository; }

    @GetMapping
    public List<AutorDTO> listar() {
        return repository.findAll().stream().map(AutorMapper::paraDTO).toList();
    }

    @GetMapping("/{id}")
    public ResponseEntity<AutorDTO> buscar(@PathVariable Long id) {
        return repository.findById(id).map(AutorMapper::paraDTO).map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<AutorDTO> criar(@RequestBody AutorDTO dto) {
        Autor salvo = repository.save(AutorMapper.paraEntidade(dto));
        return ResponseEntity.status(HttpStatus.CREATED).body(AutorMapper.paraDTO(salvo));
    }

    @PutMapping("/{id}")
    public ResponseEntity<AutorDTO> atualizar(@PathVariable Long id, @RequestBody AutorDTO dto) {
        if (!repository.existsById(id)) return ResponseEntity.notFound().build();
        Autor autor = AutorMapper.paraEntidade(dto);
        autor.setId(id);
        return ResponseEntity.ok(AutorMapper.paraDTO(repository.save(autor)));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id) {
        if (!repository.existsById(id)) return ResponseEntity.notFound().build();
        repository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
