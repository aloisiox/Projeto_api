package com.livros.projeto.controllers;

import com.livros.projeto.dtos.LivroDTO;
import com.livros.projeto.dtos.LivroMapper;
import com.livros.projeto.models.Livro;
import com.livros.projeto.repositories.LivroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/livros")
public class LivroController {

    @Autowired
    private LivroRepository repository;

    @GetMapping
    public ResponseEntity<List<LivroDTO>> listarTodos(){
        List<Livro> livros = repository.findAll();

        List<LivroDTO> dtos = livros.stream()
                .map(LivroMapper::paraDTO)
                .collect(Collectors.toList());

        return ResponseEntity.ok(dtos);
    }

    @GetMapping("/{id}")
    public ResponseEntity<LivroDTO> buscarPorId(@PathVariable Long id) {
        return repository.findById(id)
                .map(LivroMapper::paraDTO)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<LivroDTO> criar(@RequestBody LivroDTO dto) {
        Livro novoLivro = LivroMapper.paraEntidade(dto);
        Livro livroSalvo = repository.save(novoLivro);

        return ResponseEntity.status(HttpStatus.CREATED).body(LivroMapper.paraDTO(livroSalvo));
    }
    @PutMapping("/{id}")
    public ResponseEntity<LivroDTO> atualizar(@PathVariable Long id, @RequestBody LivroDTO dto) {
        if (!repository.existsById(id)){
            return ResponseEntity.notFound().build();
        }
        Livro livroatualizador = LivroMapper.paraEntidade(dto);
        livroatualizador.setId(id);

        Livro livrosalvo = repository.save(livroatualizador);
        return ResponseEntity.ok(LivroMapper.paraDTO(livrosalvo));
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        if (!repository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        repository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
