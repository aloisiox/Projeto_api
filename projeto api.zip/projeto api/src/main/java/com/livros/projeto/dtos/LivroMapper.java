package com.livros.projeto.dtos;
import com.livros.projeto.models.Livro;

public class LivroMapper {


    public static LivroDTO paraDTO(Livro livro){
        return new LivroDTO(
                livro.getId(),
                livro.getTitulo(),
                livro.getAutor()
        );
    }
    public static Livro paraEntidade(LivroDTO dto) {
        Livro livro = new Livro();
        livro.setTitulo(dto.getTitulo());
        livro.setAutor(dto.getAutor());
        return livro;
    }
}
