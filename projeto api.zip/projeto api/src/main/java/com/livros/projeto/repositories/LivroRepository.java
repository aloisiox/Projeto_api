package com.livros.projeto.repositories;

import com.livros.projeto.models.Livro;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LivroRepository extends JpaRepository<Livro, Long> {
}

