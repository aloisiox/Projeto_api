package com.livros.projeto.dtos;

public class TokenDTO {
    private String token;
    private String tipo = "Bearer";

    public TokenDTO() { }
    public TokenDTO(String token) { this.token = token; }
    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }
}
