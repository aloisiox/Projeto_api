package com.livros.projeto.dtos;

import com.livros.projeto.models.Autor;

public class AutorMapper {
    public static AutorDTO paraDTO(Autor autor) {
        return new AutorDTO(autor.getId(), autor.getNome(), autor.getNacionalidade());
    }

    public static Autor paraEntidade(AutorDTO dto) {
        Autor autor = new Autor();
        autor.setNome(dto.getNome());
        autor.setNacionalidade(dto.getNacionalidade());
        return autor;
    }
}
