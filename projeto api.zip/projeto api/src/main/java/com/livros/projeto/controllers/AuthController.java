package com.livros.projeto.controllers;

import com.livros.projeto.dtos.LoginDTO;
import com.livros.projeto.dtos.RegistroDTO;
import com.livros.projeto.dtos.TokenDTO;
import com.livros.projeto.dtos.UsuarioDTO;
import com.livros.projeto.models.Usuario;
import com.livros.projeto.repositories.UsuarioRepository;
import com.livros.projeto.services.JwtService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {
    private final UsuarioRepository usuarios;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public AuthController(UsuarioRepository usuarios, PasswordEncoder passwordEncoder, JwtService jwtService) {
        this.usuarios = usuarios;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
    }

    @PostMapping("/registro")
    public ResponseEntity<?> registrar(@RequestBody RegistroDTO dto) {
        if (dto.getNome() == null || dto.getNome().isBlank()
                || dto.getEmail() == null || dto.getEmail().isBlank()
                || dto.getSenha() == null || dto.getSenha().length() < 8) {
            return ResponseEntity.badRequest().body("Informe nome, email e senha com pelo menos 8 caracteres.");
        }
        String email = dto.getEmail().trim().toLowerCase();
        if (usuarios.existsByEmail(email)) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Este email já está cadastrado.");
        }
        Usuario usuario = new Usuario();
        usuario.setNome(dto.getNome().trim());
        usuario.setEmail(email);
        usuario.setSenhaHash(passwordEncoder.encode(dto.getSenha()));
        Usuario salvo = usuarios.save(usuario);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(new UsuarioDTO(salvo.getId(), salvo.getNome(), salvo.getEmail()));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginDTO dto) {
        if (dto.getEmail() == null || dto.getSenha() == null) {
            return ResponseEntity.badRequest().body("Informe email e senha.");
        }
        return usuarios.findByEmail(dto.getEmail().trim().toLowerCase())
                .filter(usuario -> passwordEncoder.matches(dto.getSenha(), usuario.getSenhaHash()))
                .<ResponseEntity<?>>map(usuario -> ResponseEntity.ok(new TokenDTO(jwtService.gerarToken(usuario.getEmail()))))
                .orElseGet(() -> ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Email ou senha inválidos."));
    }
}
